#include<iostream>
#include <windows.h>
#include<conio.h>
#include <string.h>
#include <ctime>
#include<fstream>
//#include <stblib.h>
using namespace std;

			
  /*  _Author_ = JAMES ANZURUNI
      _Email_ = jamesanzuruniwilondja@gmail.com 
	  _Github_ = https://github.com/jamesanzuruni44 
	  
	  
###########################################################################################
# 																						  #
#       FIND CORRECT WEEKDAY FROM EXACT DATE OR MONTH ENTERED BY THE USER                                                                                         #
#                                                                                         #
########################################################################################### 

*/ 
  
 //check day
 bool check_date(int day , int month){
	if( (month==2) && (day>0) && (day<30)){
	return true;	
		
	}
	if(( (month==1)||
   		 (month==3)||
         (month==5)||  
		 (month==7)||
		 (month==8)||
		 (month==10)||
		 (month==12)
		 ) &&  ((day>0) && (day<32)) )
		 {
		 	return true ;
		 }
		 
		 if(( 
		 	(month==4)||
			(month==6)||
			(month==9)||
			(month==11)	 
		 ) && ((day>0) && ( day<3)))
		 {
		 	return true;
		 }	 
		 return false;
 }
 
 //check month
 bool check_month(int month){
	 
	 if ((month>0) && (month<13)){
		 return true;
	 }
	 else{
		 return false;
	 }
 }
 
 //check year
 bool check_year(int year){
	 if((year>999) && (year < 10000)){
		 return true;
	 }
	 else{
		 return false;
	 }
 }

 
 //is it leap year
 
  bool check_leap_year(int year){
	 if (((year% 4)==0) && ((year % 100)!=0)){
	return true;	 
	 }
	 else if((year%400)==0){
	 	return true;
		 
	 }
	 else{
		 return false;
	 }
	 
	 
 }
 
 
 //get exact day from the date entered by user ////
 /// i used julian_day #calculation  /////
 /// let us start here .....!!!!!!!!!!!!!!
 const char *get_day(int day , int month , int year ){
	 int JMD;
	 JMD = (day + ((153 * (month + 12 * ((14 - month) / 12) - 3) + 2) / 5) +
	 (365 *(year + 4800 - ((14 - month) / 12)))+
	 ((year + 4800 - ((14 - month) / 12)) / 4)-   
	 ((year + 4800 - ((14 - month) / 12)) / 100)+
	 ((year + 4800 - ((14 - month) / 12)) / 400) - 32045) % 7;
	 
	 // cout << JMD;
	 
	 const char *weekday[] = {"Monday",
	 	 "Tuesday",
	 	 "Wednesday",
	 	 "Thursday",
	 	 "Friday" ,
	 	 "Saturday" ,
		 "Sunday"};
		 return weekday[JMD];
 }

 
 
//// The main function start heere /////
int main(int argc, char** argv)
{
	
	
	
// instalise variable	
 string name;
 int year,date,month, x , y;
 char gender;
 //int age;
//age=2021-yearofbirth;
 
 ///Declaration and initialization of Welcoming page start here//////
 
    int i,j,k;
    for(i=0; i<80; i++)
    {
        cout<<"\xdb";
    }
    cout<<"\n";
    for(i=0; i<80; i++)
    {
        cout<<"\xdb";
    }
    system("color 9a");
    cout<<" \t_______________________________________________________\n";
    cout<<"\t|                                                      |\n";
    cout<<"\t|**WELCOME TO C++ PROGRAM,,, GETTING YOUR AGE SYSTEM PROJECT|**\n";
    cout<<"\n\t|                                                      |\n";
    cout<<"\t ______________________________________________________\n";
    cout<<"\t|    DEVELOPED BY AMRUCODERS PROGRAMMER TEAM             |\n";
    cout<<" \t________________________________________________________\n";
    cout<<"\t|    *****************************************            |\n";
    cout<<"\t        ***** WELCOME TO AMRUCODERS PROGRAMMER ***** \n";
    cout<<"\t|    *****************************************            |\n";
    cout<<" \t_______________________________________________________\n";
    cout<<"\n\tPLEASE ENTER ANY KEY TO CONTINUE";
    for(i=0; i<5; i++)
    {
        cout<<".";
        Sleep(500);//after printing one . another comes after 0.5 seconds
    }
////Welcome Ends up here//////
	 getch();
    system("cls");//clears the screen
    cout<<"\n";
    for(i=0; i<80; i++)
    {
        cout<<"\xdb";
    }
   
 
    system("color 6b");
    
    cout<<"\n\n\n\n";
    
    cout<<"\t\t\t\t#|######################################################|#\t\t\t\t\n";
 	cout<<"\t\t\t\t#|                                                      |#\n";
	cout<<"\t\t\t\t#| FILL YOUR DETAILS TO GET  AGE::|#\t\t \t\t\n"; 
	cout<<"\t\t\t\t#|                                                      |#\n";
	cout<<"\t\t\t\t#|                                                      |#\n";
	cout<<"\t\t\t\t#|######################################################|#\t\t \t\t \n"; 
	cout<<"Please  Enter your Name \n";
	cout<<" [ NAME ]  :  ";
	cin>>name;
	cout<<"\t\t***************************\t\t\n";
	cout<<"\t\t*::: Enter the DOB ::: *\t\t"<<endl;
	cout<<"\t\t***************************\t\t \n";
	cout<<"Enter date \n";
	cout<<" [ DD ]  :  ";
	cin>>date;
//	verify date
	if (check_date(month,date)){
		cout<<"\n\t[-] DATE IS VERIFIED";
	}
	else{
		cout<<"\n\t [-] DATE IS VERIFIED\n";
		
	} 
	
	
	
	
	cout<<"\n\n";
	cout<<"Enter month \n";
	cout<<" [ MM ]  :  ";
	cin>>month;
	///verify month
	if (check_month(month)){
		cout<<"\n\t[-] MONTH IS VERIFIED";
	}
	else{
		system("color 4");
		cout<<"\n\t [-] WRONG MONTH FORMAT\n";
		exit(0);
	}
	
	cout<<"\n\n";
	cout<<"Enter year \n";
	cout<<" [ YYYY ]  :  ";
	cin>>year;
	///verify year
	if (check_year(year)){
		cout<<"\n\t[-] YEAR IS VERIFIED";
	}
	else{
		system("color 4");
		cout<<"\n\t [-] WRONG YEAR FORMAT\n";
		exit(0);
	}
	cout<<"\n\n";
	cout<<"Enter Gender \n";	
	cout<<" [ M/m OR F/f ]:";
	cin>>gender;
	
	
	///verify the gender using  #switch statement
	switch(gender)
	{
	case  'M':
	case  'm':
	cout<<"\t\tMale";		
		break;
	case  'F':
	case  'f':
	cout<<"\t\tFemale";
		break;
	default:
		system("color 4");
		cout<<"\t\t\tINVALID GENDER \n";
		exit(0);
		cout<<"\n\n\n\n";
	}
	
	
	
	
	
	
///We have used The If condition to validate and invalidate the year entered by the user //////
///Again we gonna use looping to find the day of User's birth //////
		
//if(yearofbirth<1925 || yearofbirth>2021)
//{
 
//	cout<<"THE YEAR ENTRED IS INVALID \n";
//}
/*else
{
cout<<"\t\t...........................................\t \t \n";
		cout<<"\t \t  HELLO,, YOUR AGE  IS  :\t \t "<<age<<endl;
cout<<"\t\t...........................................\t \t \n";	
}*/


//// We are going to get the of the user's age from this  program /////



//int age;
//age=2021-yearofbirth;

	
	
int age;
age=2022-year;

if(year<1880 || year>2022)
{
	
	 system("color 4");
	 cout<<"THE YEAR ENTRED IS INVALID \n";
	 exit(0);
}
else
{
	
cout<<"\n\n\\n";
cout<<"\t\t..............................................................\t \t \n";
		cout<<"\t \t:  HELLO..!!,\t"<<name<<"\tYOUR AGE  IS  :\t"<< age<<endl;
cout<<"\t\t...............................................................\t \t \n";
}


//if(yearofbirth<1925 || yearofbirth>2021)
//{
 
//	cout<<"THE YEAR ENTRED IS INVALID \n";
//}
		   cout<<"\n";
    for(i=0; i<80; i++)
    {
        cout<<"\xdb";
    }
    
 /* *******HERE WE ARE DECLARING AND INITIALIZING THE CURRENT DATE AND TIME**********  */ 
 
   
	////current date/time based on current system ///////////////
	time_t now  = time(0);
	
	
	//// we are going to convert now to string form  //////// 
	char* dt = ctime(&now); 
	
	

	
		
    cout<<"\n\n\n\n";	
	cout<<"\t\t@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\t\t\t\n";
	cout<<"\n\n";
	cout<<"\t\t\tHERE IS YOUR BIRTHDAY\n";
	cout<<"\t\t\tYou are born on \n";
	cout<<"\t\t\tDate : " <<date<< " / Month : " <<month<< " / Year :  "<<year<< endl;
	cout<<"\t\t\t"<<get_day(date,month, year);
	cout<<"\n\n";
	
	cout<<"\t\t@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\t\t\t\n";
	cout<<"\n\n";
	 if (((year% 4)==0) && ((year % 100)!=0)){
	cout<<"\t\t\t[ THIS IS A LEAP YEAR  " <<year<< " ]  \n" ;	 
	 }
	  else if((year%400)==0){
	cout<<"\t\t\t[ THIS IS A LEAP YEAR   " <<year<< " ]  \n"; 	
		 
	 }
	 else{
	cout<<"\t\t\t[ THIS IS NOT A LEAP YEAR  " <<year<< " ]  ";
	 }
	 cout<<"\n\n";
	cout<<"\t\t@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\t\t\t\n";
	
	
	cout<<"\t\t\t the local time is " << dt <<endl;
	
	//convert now to tm struct for 
	tm*gmtm = gmtime(&now);
	dt = asctime(gmtm);
	cout<<"\t\t\t The UTC date and time is " << dt <<endl;
	
 
	
	
	

	return 0;
}